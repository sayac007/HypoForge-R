# hypoforgeR — independent R foundation

Experimental R counterpart to [HypoForge Python](https://github.com/sayac007/HypoForge-Feature-Discovery). **Version 0.1.0 is not feature-discovery parity.** It implements standalone calendar hypotheses and deterministic MMM-inspired transforms, with a matching conceptual API. Full candidate generation, scoring, safety, selection and tournament are future milestones.

## Install from local package directory

```r
install.packages('.', repos = NULL, type = 'source')
library(hypoforgeR)
```

## Examples

```r
hf_easter(2026)
dates <- seq(as.Date('2026-03-01'),as.Date('2026-05-01'),by='day')
f <- hf_calendar_features(dates, offsets_weeks=-10:10)
head(f[c('event_easter_w-1','event_easter_w+0','event_easter_w+1')])

spend <- c(100,0,0,80,0)
carry <- hf_geometric_adstock(spend,alpha=.6,l_max=4)
response <- hf_logistic_saturation(carry,lam=.02)
```

## Function reference

| Function | Purpose |
|---|---|
| `hf_easter(year)` | Gregorian Easter Sunday |
| `hf_calendar_features(dates, offsets_weeks, extra_events)` | Fourier seasonality and event-date offset indicators |
| `hf_scan_recurring(dates, residuals, period_days, offsets_days, min_cycles, min_hits)` | Exploratory training-residual phase scan, **not** a significance test |
| `hf_geometric_adstock(x, alpha, l_max, normalize)` | Finite geometric carryover |
| `hf_delayed_adstock(x, alpha, peak, l_max, normalize)` | Peaked lag kernel |
| `hf_weibull_adstock(x, shape, scale, l_max, normalize)` | Weibull survival-difference kernel |
| `hf_logistic_saturation(x, lam)` | Zero-based logistic saturation |
| `hf_michaelis_menten(x, half_saturation, maximum)` | Hyperbolic saturation |
| `hf_power_saturation(x, exponent)` | Concave power |
| `hf_tanh_saturation(x, scale)` | Bounded tanh response |
| `hf_reach_frequency(reach, frequency, half_saturation, slope)` | Reach × Hill-saturated frequency |

All adstock functions require an ordered, **single** time series; never apply across unseparated panels. NA exposure is treated as zero. Saturation requires nonnegative input. The calendar helper is daily-date aligned; aggregate by your actual business week if using weekly data. `hf_scan_recurring` must be applied to training residuals only.

## References and scope

See Python project's `docs/MMM_TRANSFORMS_AND_SOURCES.md` for primary source links to Meta Robyn, Google Meridian, Google LightweightMMM and PyMC-Marketing. These are independently implemented mathematical families, not identical drop-in transformations.

Apache-2.0. Replace the placeholder maintainer email in DESCRIPTION with a real project contact before publication. Create a **separate GitHub repository** for this package; do not nest the R package in the Python repository.

## Native R discovery engine (experimental)

This package now provides `hf_spec`, `hf_evaluate`, `hf_generate`, `hf_safety`,
`hf_discover`, `hf_select`, `hf_rolling_splits`, and `hf_tournament` as native R
functions. It does **not** require Python or reticulate.

```r
set.seed(14)
n <- 320
x <- rnorm(n); signal <- rnorm(n)
d <- data.frame(week=seq_len(n), x=x, signal=signal,
                sales=2*x + 3*signal + rnorm(n, sd=.5))
result <- hf_tournament(d, 'sales', 'week', 'x',
  list(hf_spec('signal', 'identity', 'signal')),
  availability=c(x='known_future', signal='known_future'),
  min_train=100, horizon=20)
print(result$summary)
```

The tournament intentionally excludes transformations with parameters fitted
on full data, and row-based lags/rolling features without an origin-aware
forecast contract. Screening uses a native ridge model; results are not a
substitute for an untouched holdout. The R discovery ranker uses absolute
Pearson correlation and is **not mathematically identical** to the Python
mutual-information ranker. Native R parity is therefore functional, not
algorithmic. Run `R CMD check .` before release.
